#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

#define DHTPIN 15
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Bróker MQTT Público
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

// Tópicos personalizados con tu apellido ya colocado
const char* topic_temp = "gerolimich/dht22/temperatura";
const char* topic_hum = "gerolimich/dht22/humedad";
const char* topic_json = "gerolimich/dht22/datos"; 

WiFiClient espClient;
PubSubClient client(espClient);
unsigned long lastMsg = 0;

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Conectando a ");
  Serial.println(ssid);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("¡WiFi conectado!");
  Serial.print("IP local: ");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Intentando conexion MQTT...");
    String clientId = "ESP32Cliente-" + String(random(0, 0xffff));
    
    if (client.connect(clientId.c_str())) {
      Serial.println("¡Conectado al broker HiveMQ!");
    } else {
      Serial.print("Fallo, rc=");
      Serial.print(client.state());
      Serial.println(" Reintentando en 5 segundos...");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
  dht.begin();
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  unsigned long now = millis();
  if (now - lastMsg > 2000) {
    lastMsg = now;

    float h = dht.readHumidity();
    float t = dht.readTemperature();

    if (isnan(h) || isnan(t)) {
      Serial.println("¡Error al leer el sensor DHT22!");
      return;
    }

    client.publish(topic_temp, String(t, 1).c_str());
    client.publish(topic_hum, String(h, 1).c_str());

    String jsonPayload = "{\"temp\": " + String(t, 1) + ", \"hum\": " + String(h, 1) + "}";
    client.publish(topic_json, jsonPayload.c_str());

    Serial.print("Datos enviados -> ");
    Serial.println(jsonPayload);
  }
}